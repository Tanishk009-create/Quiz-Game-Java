package game.story;

import game.GameStage;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class PrologueDisplay extends JFrame implements GameStage {
    private ArrayList<String> prologueLines;
    private int currentLineIndex = 0;
    private Timer timer;
    private String currentLine = "";
    private Runnable onCompleteListener;

    public PrologueDisplay() {
        setTitle("Prologue: The Fall of Javaria");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Load lines
        prologueLines = new ArrayList<>();
        prologueLines.add("In the ancient kingdom of Javaria, knowledge was the greatest treasure.");
        prologueLines.add("The people mastered the art of logic, building wonders using the mystical language of Java.");
        prologueLines.add("At the heart of their power was the Book of Code, a tome that held the secrets to creation itself.");
        prologueLines.add("The Codemasters guarded these sacred laws, teaching the principles of inheritance, encapsulation, and polymorphism.");
        prologueLines.add("But all empires fall. A group of rebels, the Nullifiers, rose from within, seeking chaos over structure.");
        prologueLines.add("They disrupted the balance, breaking the very laws that held Javaria together.");
        prologueLines.add("The war was fierce, and in the end, the Book of Code was lost, its pages scattered.");
        prologueLines.add("The Temple of Java was destroyed, and the kingdom crumbled into ruin.");
        prologueLines.add("Javaria's knowledge was buried beneath time's sands, its wisdom forgotten by all but a few.");
        prologueLines.add("The once-great empire faded into legend, leaving only whispers of its power.");

        ProloguePanel panel = new ProloguePanel();
        add(panel);

        initializeTimer();
        setupKeyListener();
    }

    private void initializeTimer() {
        timer = new Timer(3000, e -> {
            if (currentLineIndex < prologueLines.size()) {
                currentLine = prologueLines.get(currentLineIndex);
                currentLineIndex++;
                repaint();
            } else {
                timer.stop();
                triggerCompletion();
            }
        });
        timer.setInitialDelay(1000);
        timer.start();
    }

    private void setupKeyListener() {
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    triggerCompletion();
                }
            }
        });
    }

    private void triggerCompletion() {
        if (onCompleteListener != null) {
            dispose();
            onCompleteListener.run();
        }
    }

    @Override
    public void start() {
        setVisible(true);
    }

    @Override
public void dispose() {
    if (timer != null && timer.isRunning()) {
        timer.stop();
    }
    super.dispose();
}

    @Override
    public void setOnCompleteListener(Runnable listener) {
        this.onCompleteListener = listener;
    }

    class ProloguePanel extends JPanel {
        private Image background;

        public ProloguePanel() {
            try {
                // Fix image path (remove extra quotes)
                background = new ImageIcon("C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Burn.jpg").getImage();
            } catch (Exception e) {
                System.out.println("Image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(background, 0, 0, getWidth(), getHeight(), this);

            if (!currentLine.isEmpty()) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2d.setFont(new Font("Serif", Font.BOLD, 24));
                g2d.setColor(Color.WHITE);

                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(currentLine);
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();

                // Shadow effect
                g2d.setColor(Color.BLACK);
                g2d.drawString(currentLine, (getWidth() - textWidth)/2 + 2, y + 2);
                
                // Main text
                g2d.setColor(Color.WHITE);
                g2d.drawString(currentLine, (getWidth() - textWidth)/2, y);
            }
        }
    }
}