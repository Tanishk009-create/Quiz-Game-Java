package game.story;

import game.GameStage;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class EpilogueDisplay extends JFrame implements GameStage {
    private ArrayList<String> epilogueLines; // Fixed variable name
    private int currentLineIndex = 0;
    private Timer timer;
    private String currentLine = "";
    private Runnable onCompleteListener;

    public EpilogueDisplay() {
        setTitle("Epilogue: The Ultimate Language of Engineers");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Load lines
        epilogueLines = new ArrayList<>();
        epilogueLines.add("The wind whispers over the ruins of Javaria, no longer silent.");
        epilogueLines.add("You stand amidst the echoes of forgotten brilliance — scrolls gathered, riddles solved, truths unearthed.");
        epilogueLines.add("One by one, the fragments of ancient wisdom came alive in your hands.");
        epilogueLines.add("You deciphered inheritance through shadows, unlocked the gates of encapsulation, reasoned with threads of time, and summoned the force of interfaces and exceptions.");
        epilogueLines.add("You didn’t just learn Java —\nYou revived it.");
        epilogueLines.add("Javaria’s legacy now pulses through your veins. Its laws are no longer buried in scrolls, but etched into your mind — classes, objects, packages, logic, structure, and flow.");
        epilogueLines.add("The Codemasters once guarded this wisdom.\nNow, you are one of them.");
        epilogueLines.add("You don’t just write Java.\nYou understand it.");
        epilogueLines.add("The city may remain in ruins, but Javaria lives again —\nin you.");

        EpiloguePanel panel = new EpiloguePanel();
        add(panel);

        initializeTimer();
        setupKeyListener();
    }

    private void initializeTimer() {
        timer = new Timer(3000, e -> {
            if (currentLineIndex < epilogueLines.size()) {
                currentLine = epilogueLines.get(currentLineIndex);
                currentLineIndex++;
                repaint();
            } else {
                timer.stop();
                triggerCompletion();
            }
        });
        timer.setInitialDelay(1000);
        timer.start();
    }

    private void setupKeyListener() {
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    triggerCompletion();
                }
            }
        });
    }

    private void triggerCompletion() {
        if (onCompleteListener != null) {
            dispose();
            onCompleteListener.run();
        }
    }

    @Override
    public void start() {
        setVisible(true);
    }

    @Override
public void dispose() {
    if (timer != null && timer.isRunning()) {
        timer.stop();
    }
    super.dispose();
}

    @Override
    public void setOnCompleteListener(Runnable listener) {
        this.onCompleteListener = listener;
    }

    class EpiloguePanel extends JPanel {
        private Image background;

        public EpiloguePanel() {
            try {
                // Fixed image path
                background = new ImageIcon("C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Castle.jpg").getImage();
            } catch (Exception e) {
                System.out.println("Image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(background, 0, 0, getWidth(), getHeight(), this);

            if (!currentLine.isEmpty()) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2d.setFont(new Font("Serif", Font.BOLD, 24));
                g2d.setColor(Color.WHITE);

                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(currentLine);
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();

                // Shadow effect
                g2d.setColor(Color.BLACK);
                g2d.drawString(currentLine, (getWidth() - textWidth)/2 + 2, y + 2);
                
                // Main text
                g2d.setColor(Color.WHITE);
                g2d.drawString(currentLine, (getWidth() - textWidth)/2, y);
            }
        }
    }
}