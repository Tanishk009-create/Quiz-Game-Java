package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level1 extends BaseLevel {
    private final String[][] questions = {
        {
                    "In the ruins of Javaria, a statue named Constructor stands headless. Which inscription would complete it without breaking the ancient law of object creation?",
                    "It wears the crown of void, for it returns nothing.",
                    "It bears the same name as the kingdom it serves.",
                    "It lies in the shadows, marked as static.",
                    "It whispers only to the private ones.",
                    "b"
            },
            {
                    "A scroll reads: new Mage(). What hidden element must lie beneath the Mage’s robes for the summoning to succeed?",
                    "An ancient chant called Mage() embedded within the class.",
                    "A magical staff stored as a static relic.",
                    "A relic passed from superclass",
                    "A symbol of invocation within an interface.",
                    "a"
            },
            {
                    "The class Artifact guards its treasure with private seals. How does the descendant Relic dare peek inside?",
                    "Break the seal with a direct incantation.",
                    "Whisper the getters’ charm through reflection.",
                    "Summon a public servant to retrieve it.",
                    "Overthrow privacy using super.",
                    "c"
            },
            {
                    "A class marked final lies at the end of a crumbled path. What does this signify?",
                    "It can no longer birth descendants.",
                    "It locks its methods in eternal silence.",
                    "It vanishes at runtime.",
                    "It cannot be instantiated, only inherited.",
                    "a"
            },
            {
                    "Two spells collide: == and equals(). One gazes at shadows, the other sees the soul. Who sees what?",
                    "== binds to the blueprint.",
                    "equals() compares their essence.",
                    "== senses inherited traits.",
                    "equals() returns memory fragments.",
                    "b"
            },
            {
                    "A mirror speaks: \"Override me and the world shall see your true form.\" What mirror is this?",
                    "The Mirror of Abstracts.",
                    "The Interface of Identity.",
                    "The toString() artifact of Object.",
                    "The void of static.",
                    "c"
            },
            {
                    "A field lies across all instances, untouched by time. It’s marked static. What does it guard?",
                    "A treasure unique to each traveler.",
                    "A shared spell among all beings.",
                    "A variable reborn in every class.",
                    "A trap that resets on each call.",
                    "b"
            },
            {
                    "An echo whispers this.name. Who is this that speaks in the empty hall?",
                    "A wandering instance of the current being.",
                    "The ghost of a superclass.",
                    "The name of the file where it resides.",
                    "A whisper from the future child.",
                    "a"
            },
            {
                    "A recursive mirror forms in the temple: class Blade { Blade b = new Blade(); }. What trap lies within?",
                    "The spell loops eternally, consuming memory.",
                    "Blade transforms into interface.",
                    "The child consumes the parent.",
                    "An infinite inheritance tree is born.",
                    "a"
            },
            {
                    "You cast new Sword().strike(), but the spell fails. Why?",
                    "The blade is abstract, its strike undefined.",
                    "The method is declared but hidden in shadows.",
                    "strike() belongs to an unseen interface.",
                    "The Sword is silent—it knows not how to strike.",
                    "d"
            },
            {
                    "public class Map extends Object is found in a scroll. What secret lies within?",
                    "The Map has betrayed Java’s inheritance chain.",
                    "It defies the rule—Object need not be named.",
                    "All classes must extend Object explicitly.",
                    "Map uses interface, not class.",
                    "b"
            },
            {
                    "You uncover a private chamber. How might an adventurer retrieve the artifact inside?",
                    "Cast super to breach the walls.",
                    "Summon protected from the dark.",
                    "Use a public spell known as a getter.",
                    "Bypass with default magic.",
                    "c"
            },
            {
                    "“All code has a parent,” says the Oracle. Who is the ancestor if none is declared?",
                    "The Spirit of null",
                    "The Crown of Java — Object",
                    "The lost Interface",
                    "The Void Master",
                    "b"
            },
            {
                    "Two fields dwell in a class: one static, one not. Which spell sees both?",
                    "A constructor that binds both.",
                    "A method birthed in an interface.",
                    "A non-static method of the class.",
                    "A constant defined externally.",
                    "c"
            },
            {
                    "Two Strings whisper: == says false, .equals() says true. What is their tale?",
                    "They are reflections, not twins.",
                    "One shares memory, the other shares soul.",
                    "They are born of the same spell, yet stored apart.",
                    "Memory lies; equality tells the truth.",
                    "b"
            },
            {
                    "A class Orb has a static block. What happens when it is first summoned?",
                    "The block activates before constructors awake.",
                    "The block binds to every new object.",
                    "It is never executed.",
                    "It overrides all instance behavior.",
                    "a"
            },
            {
                    "A method wears the cloak public static void main(String[] args). What makes it chosen?",
                    "It is chanted by the JVM at dawn.",
                    "It holds no instance, yet leads all.",
                    "It returns nothing, thus pure.",
                    "All of the above.",
                    "d"
            },
            {
                    "A warrior creates a class Mystic. She writes Mystic m1 = new Mystic(); Mystic m2 = m1;. What happens when m1 is destroyed?",
                    "m2 vanishes too—linked souls.",
                    "m2 still holds the echo of m1.",
                    "A NullPointer prophecy is fulfilled.",
                    "They both forget their origin.",
                    "b"
            },
            {
                    "You stumble upon the line Object obj = new String(\"soul\");. What shape has the object taken?",
                    "The essence of a String in Object's clothing.",
                    "The disguise is perfect—Object behaves as Object.",
                    "The object has lost all memory.",
                    "This breaks the rules of inheritance.",
                    "a"
            },
            {
                    "A class has an object of itself inside itself. How can this paradox be resolved?",
                    "Postpone creation with a constructor delay.",
                    "Mark it static and free it from instance chains.",
                    "Summon it through an external builder.",
                    "Choose laziness with null until needed.",
                    "d"
            },
    };

    public Level1() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions;}

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Temple.jpg ";
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
            "📜: The Temple of Classes and Objects! 📜\n\n" +
            "Step into the ancient temple where all logic begins.\n" +
            "Here, classes craft the essence of life, and objects walk the realm of code.\n\n" +
            "Unlock the holy trinity — Encapsulation, Inheritance, Polymorphism — and wield the power of true structure.\n"
        );
        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }
    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
                "🎉 Congratulations, Seeker of Knowledge! 🎉\n\n" +
                        "You have answered all questions correctly.\n" +
                        "You have uncovered the lost knowledge of Javaria!\n\n" +
                        "Classes and Objects shall now bow to your command.\n\n" +
                        "May the JVM guide your path!");
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.ITALIC, 16));
        scrollText.setMargin(new Insets(20, 20, 20, 20));
        scrollText.setBackground(new Color(255, 250, 230)); // parchment-like

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 250));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();
    }
}
