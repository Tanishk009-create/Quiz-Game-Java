package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level6 extends BaseLevel {
    private final String[][] questions = {
        {
                    "Two threads begin. One yields, the other doesn't. Who finishes first?",
                    "Time may favor either — it’s the JVM’s gamble",
                    "Always the non-yielding one",
                    "The yielding one rests forever",
                    "Yield causes compile error",
                    "a"
            },
            {
                    "The run() method is called directly — not via start(). What’s the spell’s result?",
                    "The thread walks alone — no new path is forged",
                    "A new thread is born",
                    "The JVM crashes",
                    "The thread waits for others",
                    "a"
            },
            {
                    "You try to restart a thread that has finished. The portal shuts. Why?",
                    "A thread can’t be started twice — its fate is sealed",
                    "The JVM resurrects it",
                    "You must override finalize()",
                    "Only daemon threads can restart",
                    "a"
            },
            {
                    "In the land of synchronization, one lock rules all. What happens if a thread doesn't release the lock?",
                    "Others wait forever — a cursed deadlock",
                    "They proceed anyway",
                    "JVM ignores the lock",
                    "The thread is terminated",
                    "a"
            },
            {
                    "Which method acts like a sleep spell, halting time for the thread without losing the lock?",
                    "Thread.sleep()",
                    "wait()",
                    "yield()",
                    "suspend()",
                    "a"
            },
            {
                    "One thread dies. Another calls join() on it. What is the consequence?",
                    "The second thread continues — no delay in mourning",
                    "It waits until the dead thread is buried",
                    "Both hang forever",
                    "The JVM throws InterruptedException",
                    "b"
            },
            {
                    "What happens when two threads call a synchronized method on the same object?",
                    "One enters, the other waits — only one lock to pass",
                    "Both execute freely",
                    "JVM throws a race exception",
                    "They deadlock immediately",
                    "a"
            },
            {
                    "Which of the following stops a thread’s journey but doesn’t free the monitor it holds?",
                    "sleep() — it guards its lock while dozing",
                    "wait()",
                    "notify()",
                    "yield()",
                    "a"
            },
            {
                    "The spell reads:\njava\nCopyEdit\nThread t = new Thread();\nt.run();\nWhat realm does the code execute in?",
                    "Main thread — the run() spell wasn’t invoked properly",
                    "A new thread is born",
                    "Compilation error",
                    "JVM throws IllegalThreadStateException",
                    "a"
            },
            {
                    "Which of the following is NOT a method of the Thread class?",
                    "wait() — it belongs to Object, not the thread realm",
                    "start()",
                    "run()",
                    "yield()",
                    "a"
            },
            {
                    "In which case does notify() NOT wake any thread?",
                    "When no thread is waiting on the monitor",
                    "When used inside a synchronized method",
                    "When used on a thread directly",
                    "When combined with yield()",
                    "a"
            },
            {
                    "A daemon thread lives only as long as...",
                    "The non-daemon threads do",
                    "The JVM allows",
                    "It has memory allocated",
                    "It completes its task",
                    "a"
            },
            {
                    "What is the fate of a thread that calls wait() without holding the object's monitor?",
                    "A crash in the form of IllegalMonitorStateException",
                    "It waits peacefully",
                    "It loops indefinitely",
                    "It gets locked",
                    "a"
            },
            {
                    "Which thread priority number will always execute first?",
                    "None — priority is a polite request, not a command",
                    "10",
                    "1",
                    "Depends on OS only",
                    "a"
            },
            {
                    "Thread A holds a lock. Thread B wants it. Thread A sleeps. What now?",
                    "Thread B still waits — sleep doesn’t release the key",
                    "Thread B proceeds immediately",
                    "Both sleep",
                    "JVM decides randomly",
                    "a"
            },
            {
                    "You want threads to speak in turn. What tool keeps the conversation orderly?",
                    "Synchronized blocks — the council of order",
                    "Volatile variables",
                    "Daemon threads",
                    "Static methods",
                    "a"
            },
            {
                    "What best describes the thread lifecycle order?",
                    "New → Runnable → Running → Dead",
                    "New → Running → Ready → Destroyed",
                    "Ready → Started → Executing → Finished",
                    "Born → Awake → Sleep → Tomb",
                    "a"
            },
            {
                    "Which method can throw InterruptedException?",
                    "sleep() — disturbed dreams throw exceptions",
                    "run()",
                    "start()",
                    "yield()",
                    "a"
            },
            {
                    "What’s the secret behind volatile variables?",
                    "They prevent caching across threads — shared truth always visible",
                    "They can’t be modified",
                    "They are constant",
                    "They use locks internally",
                    "a"
            },
            {
                    "A thread holding multiple locks dies unexpectedly. What happens to those locks?",
                    "They're released — the keys drop to the floor",
                    "They’re held forever",
                    "JVM halts",
                    "Another thread must unlock manually",
                    "a"
            }
    };

    public Level6() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions; }

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Space.jpg"; 
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
                
            "📜Threads — The Realm of Duality and Time! 📜\n\n" +
            "In this dimension, time runs parallel and reality splits.\n" +
            "Threads of execution wind around each other like snakes — synchronized, racing, pausing, or dying in silence.\n" + 
            "Only those who truly grasp concurrency shall cross this temporal rift...\n"
        );

        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
                "🎉 Congratulations, Seeker of Knowledge! 🎉\n\n" +
                        "You have answered all questions correctly.\n" +
                        "You have uncovered the lost knowledge of Javaria!\n\n" +
                        "Threads shall now bow to your command.\n\n" +
                        "May the JVM guide your path!");
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.ITALIC, 16));
        scrollText.setMargin(new Insets(20, 20, 20, 20));
        scrollText.setBackground(new Color(255, 250, 230)); // parchment-like

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 250));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();

    }
}