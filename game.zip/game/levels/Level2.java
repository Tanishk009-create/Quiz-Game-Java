package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level2 extends BaseLevel {
    private final String[][] questions = {
        { 
    "The Sage once said: \"A class can inherit from one, but respect many.\" What does this mean in the scrolls of Java?",
    "A class may marry only one parent, but whisper to many interfaces.",
    "Java allows only sacred single inheritance and shuns the rest.",
    "Multiple classes can parent one subclass in spirit.",
    "Interfaces inherit all—classes none.",
    "a"
},
{ 
    "The Blade class gives its strike() method to the Dagger. But when Dagger strikes, it’s silent. Why?",
    "Dagger hides Blade’s voice with its own whisper.",
    "Dagger doesn’t override, it overloads the call.",
    "Blade’s method is marked final—unchangeable.",
    "strike() was lost in translation during casting.",
    "b"
},
{ 
    "The mage declares: public class Wizard extends Human implements Magic. Who does Wizard listen to?",
    "Only Human, the class with bones.",
    "Magic, the spirit that guides.",
    "Both — one for flesh, one for mind.",
    "Neither — Wizard walks alone.",
    "c"
},
{ 
    "A class dares to declare: super(). What forbidden ritual is being performed?",
    "A summoning of the superclass’s creation chant.",
    "A link to a distant ancestor's private realm.",
    "An override of all parent fields.",
    "A method lost in abstraction.",
    "a"
},
{ 
    "In the Temple of Extends, a class wrote: public class Child extends Parent. What secrets are passed?",
    "Methods and fields with open seals.",
    "Constructors travel with the spell.",
    "Private whispers travel too.",
    "Static relics change hands.",
    "a"
},
{ 
    "A class extends another and overrides a method, but super.method() is used inside. Why?",
    "To summon the parent’s original incantation.",
    "To escape a recursive trap.",
    "To double-cast both powers.",
    "To inherit without invoking.",
    "a"
},
{ 
    "A warrior writes: class Blade extends Sword, Shield {}. The compiler rebels. Why?",
    "Blade cannot serve two masters.",
    "Blade must declare only one path.",
    "Java permits no double bloodline.",
    "All of the above.",
    "d"
},
{ 
    "The method is final. What happens if the child class attempts to rewrite it?",
    "The compiler's wrath is unleashed.",
    "The child becomes independent.",
    "The JVM ignores the child’s voice.",
    "The method hides, not overrides.",
    "a"
},
{ 
    "The spirit of Object passes its whispers to all. How?",
    "Every class bears the mark of Object.",
    "Classes must invoke Object manually.",
    "Only interfaces inherit Object.",
    "Object is invoked via package spells.",
    "a"
},
{ 
    "A class hides its method using private. Can a subclass reveal it by declaring a new one?",
    "Yes — a new spell is written over the sealed one.",
    "No — the shadows of private extend forever.",
    "Only if it’s marked as protected.",
    "Private methods override themselves.",
    "a"
},
{ 
    "super.variableName is spoken. What truth does this unveil?",
    "The variable lives in the parent’s chest.",
    "A static relic is being summoned.",
    "A method is being called from above.",
    "It bypasses the child’s own shadow.",
    "a"
},
{ 
    "Two methods exist: one in Parent, one in Child, both with same name. What decides which is invoked?",
    "The method where the object was created.",
    "The method where the object is declared.",
    "The runtime polymorph reveals the truth.",
    "The reference type binds the outcome.",
    "c"
},
{ 
    "Abstract beings roam Javaria. They can’t be summoned, but their voices echo. What are they?",
    "Abstract classes that cannot be newed.",
    "Interfaces calling to the void.",
    "Classes with no body and no birth.",
    "Final entities with no heir.",
    "a"
},
{ 
    "A class has no constructor, yet it’s born. How?",
    "The compiler gifts a secret default ritual.",
    "Inheritance passes constructors by default.",
    "Object forces it into being.",
    "It cannot be born—this is false.",
    "a"
},
{ 
    "The line reads: Parent p = new Child();. What illusion is cast?",
    "Upcasting — hiding true identity behind an ancestor’s mask.",
    "Downcasting — a risky reversal of fate.",
    "Overriding — Parent takes control again.",
    "No inheritance is happening.",
    "a"
},
{ 
    "A warrior casts ((Child)p).attack(). When does this work?",
    "When p holds a Child within.",
    "When casting is forced and fails.",
    "If Child overrides with final.",
    "Only if Child extends an interface.",
    "a"
},
{ 
    "Can a subclass override a static method?",
    "No — static spirits do not respond to override spells.",
    "Yes — but only once.",
    "Only if final is absent.",
    "Only with the parent's permission.",
    "a"
},
{ 
    "The child class uses super() without knowing the parent’s constructor. What happens?",
    "It works only if the parent offers a no-arg constructor.",
    "The code fails at runtime.",
    "A compile-time rebellion occurs.",
    "The JVM injects an invisible default constructor.",
    "a"
},
{ 
    "In a field, this.run() and super.run() are heard. Who truly runs?",
    "this.run() speaks of the child’s steps.",
    "super.run() invokes the ancestral pace.",
    "Both are valid paths — one modern, one ancient.",
    "All of the above.",
    "d"
},
{ 
    "The keyword instanceof checks lineage. What does x instanceof Parent return?",
    "True if x is born of Parent or its heirs.",
    "True only for direct children.",
    "False for interface offspring.",
    "Always false if Parent is abstract.",
    "a"
}
    };

    public Level2() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions; }

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Cave.jpg"; 
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
            "📜:  The Caverns of Inheritance! 📜\n\n" +
            "Descend into the dark veins of code lineage.\n\n" +
            "In these caverns, parent classes pass down traits, while shadows of ambiguity wait in branching paths.\n" +
            "Only the wise can shape clean hierarchies and escape the trap of tangled descent."
        );
        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
                "🎉 Congratulations, Seeker of Knowledge! 🎉\n\n" +
                        "You have answered all questions correctly.\n" +
                        "You have uncovered the lost knowledge of Javaria!\n\n" +
                        "Inheritence shall now bow to your command.\n\n" +
                        "May the JVM guide your path!");
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.ITALIC, 16));
        scrollText.setMargin(new Insets(20, 20, 20, 20));
        scrollText.setBackground(new Color(255, 250, 230)); // parchment-like

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 250));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();
    }
}
