package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level7 extends BaseLevel {
    private final String[][] questions = {
        {

                        "<b>The Phantom Threads of Eternity</b><br><br> The Vault of Time contains the secrets of the universe, but only those who understand the art of threads can access them. The Vault's mechanism operates with two wizards, Eldar and Mira, who use threads to unlock the vault. Eldar's spell unlockVault() runs on one thread, and Mira’s spell sealVault() runs on another. Both spells must work together but must not interfere with one another. However, a deadlock occurs when both spells wait indefinitely for each other to finish their task. <br><b>Question:</b> How can the two wizards avoid the deadlock, and which Java concept will ensure that both spells complete their task without blocking each other?", 
                        "A) Implement Thread.sleep() to ensure the threads do not clash.",
                        "B) Use synchronized blocks with a well-defined order of locks to prevent deadlock.",
                        "C) Each wizard should run their spell on the same thread.",
                        "D) Both spells should not use any threads and should instead run on the main method.",
                        "b"

                },
                
                {
                        "<b>The Scroll of Inheritance and Overriding</b><br><br> The Ancient Order of Coders created a mighty hierarchy of magical beings, each with distinct powers. Wizard, a base class, grants a castSpell() method. Sorcerer and Enchanter are subclasses of Wizard, each overriding castSpell() to provide their own mystical power. A Summoner must choose the proper subclass to call the spell from, but the hierarchy is complicated. The Summoner wishes to cast the spell using the Sorcerer’s magic but faces confusion due to the Enchanter’s spell being called instead. <br><b>Question:</b> When the Summoner calls castSpell(), which spell will be invoked, and how does method overriding affect this?",
                        "A) The Sorcerer’s spell will always be invoked because it is the last subclass.",
                        "B) The Enchanter’s spell will be invoked because it is higher in the inheritance chain.",
                        "C) The Summoner’s castSpell() method will be invoked, overriding both Sorcerer and Enchanter.",
                        "D) The method invoked depends on the object’s actual type, so the Summoner will override everything.",
                        "d"
                },

                {
                        "<b>The Enchanted Wall of Static and Instance Powers</b><br><br> Deep within the Cavern of Knowledge, a stone wall stands between you and the treasure. The stone is sealed by two types of magic: static magic, which is universal, and instance magic, which affects only the chosen user. Lance, a noble Warrior, invokes static power to call a storm (summonStorm()), while his companion Mira, a Sorceress, casts her instance spell (summonFireball()), unique to each Sorceress. The wall allows only one spell at a time. But there is a condition: static methods work for all, while instance methods work only for their objects. <br><b>Question:</b> When Lance calls summonStorm() (static) and Mira calls summonFireball() (instance) simultaneously, what will happen to the magic, and which method will be invoked?",
                        "A) Both static and instance methods will work at the same time without interference.",
                        "B) Static methods can be invoked without objects, so summonStorm() will work, while summonFireball() fails.",
                        "C) Only summonFireball() will succeed because instance methods are stronger than static ones.",
                        "D) Both methods will clash and result in a method resolution conflict.",
                        "a"
                },

                {
                        "<b>The Curse of Polymorphic Magic</b><br><br> The ancient Alchemist’s Circle believes that polymorphism can be used to control powerful magic. The first stone contains the base spell transform() in the Shape class. Square and Circle are subclasses of Shape, and each implements transform() in different ways. However, when Alchemist creates a polymorphic reference to Shape, they attempt to invoke transform() using an object reference of type Shape, but the resulting transformation is not what they expected. <br><b>Question:</b> Given that Alchemist uses polymorphism to cast the spell, which method will actually be invoked when calling transform() through the Shape reference?",
                        "A) The Shape method will be invoked because polymorphism binds all references to the base class.",
                        "B) The Square method will be invoked, as it is the first subclass in the chain.",
                        "C) The actual object type determines the method invocation, so the Circle spell will be invoked if the object is a Circle.",
                        "D) The method invocation depends on the static binding of the reference, meaning the base class method will always be invoked.",
                        "c"
                },

                        {
                        "<b>The Test of Deadlock and Thread Conflict</b><br><br> At the heart of the Throne Room, the King's Machine operates using two threads: KingThread and GuardThread. Each thread locks a resource to perform its task—KingThread locks the royal chamber, and GuardThread locks the gate. However, if each thread tries to lock the other’s resource, a deadlock occurs, leaving the kingdom in chaos. <br><b>Question:</b> How can the King’s engineers prevent the deadlock while allowing both threads to complete their tasks in parallel?",
                        "A) Use Thread.join() to synchronize both threads.",
                        "B) Lock resources in a consistent order using synchronized to ensure one thread always finishes first.",
                        "C) Remove synchronization entirely to allow threads to run without interference.",
                        "D) Use Thread.sleep() to ensure threads do not encounter each other.",
                        "b"
                        },

                        {
                        "<b>The Binding Ritual of Static and Final Fields</b><br><br> In the Cavern of Eternity, a powerful Witch holds a secret: final fields cannot be altered once set, and static fields are shared by all objects. She has a final field for her magicPower and a static field for her guildName. Both fields affect her spellcasting abilities, but the final nature of magicPower limits her changes, while guildName must always be the same across her clan. <br><b>Question:</b> What happens when the Witch tries to change the magicPower and guildName fields in her subclasses?",
                        "A) The final field cannot be altered, while the static field can be altered by all subclasses.",
                        "B) Both fields can be modified freely in subclasses. ",
                        "C) magicPower can be changed, but guildName cannot be altered after initialization. ",
                        "D) Both fields are immutable, and their values cannot change in any subclass.",
                        "a"
                        },

                        {
                        "<b>The Lost Knowledge of Interfaces</b><br><br> In the Library of Echoes, Scribes write their knowledge in books, but each book has different bindings: some are enchanted, and others are not. InterfaceBook contains a magical read() method, which is implemented by two subclasses: MysticBook and AncientBook. The Sorcerer can only read books that implement InterfaceBook, but the CursedBook implements a similar method without the interface. <br><b>Question:</b> When the Sorcerer tries to read a CursedBook (which doesn’t implement the interface), what will happen, and how does interface inheritance play a role?",
                        "A) The CursedBook can be read if it implements InterfaceBook.",
                        "B) The CursedBook will cause a compile-time error because it doesn't implement the interface.",
                        "C) The Sorcerer can read any book, whether or not it implements InterfaceBook.",
                        "D) The CursedBook will be treated as an object of InterfaceBook, but the read() method will not work.",
                        "b"
                        },

                        {
                        "<b>The Magical Array of Summons</b><br><br> The Summoning Circle has an Array of 5 summoned creatures. Each creature has a unique power, but the circle can only hold a fixed number of creatures at any time. ArrayList is the key, but only the most dynamic summons can be added. The question lies: when is the correct ArrayList size revealed, and how does dynamic resizing help the summoner? <br><b>Question:</b> If the Summoner tries to exceed the initial capacity of an ArrayList of summoned creatures, what will happen, and which feature helps with resizing?",
                        "A) The ArrayList will throw an IndexOutOfBoundsException.",
                        "B) The ArrayList will automatically resize itself and increase its capacity as needed.",
                        "C) The ArrayList will resize itself only if the size is declared final.",
                        "D) The ArrayList will lock itself, and no new creatures can be summoned after the size limit.",
                        "b"
                        },

                        {
                        "<b>The Curse of Encapsulation</b><br><br> Deep within the Cavern of Shadows, the Alchemist kept his secrets locked away using the powerful magic of encapsulation. His magical gems were hidden behind private fields, but there was a ritual to unlock the fields when necessary. <br><b>Question:</b> Which of the following will allow access to private fields using the ritual, and how does encapsulation help prevent unauthorized use?",
                        "A) Directly access private fields via subclass methods.",
                        "B) Use getter and setter methods to reveal the private fields.",
                        "C) Private fields cannot be accessed by any method, not even a getter.",
                        "D) Accessing private fields is only possible using the reflection API.",
                        "b"
                        },

                {
                        "<b>The Binding of the Final Thread</b><br><br> Finally, the Mysterious Gatekeeper watches over the final threshold to Javaria. Only those who understand how to finalize objects may pass through the gate. He holds a final spell, but only objects that pass certain criteria can invoke it. <br><b>Question:</b> When a finalized object enters the room, which method of finalization will be used to clean up resources, and what happens to the object's lifecycle?",
                        "A) Finalize() will be called when the object is no longer in use and eligible for garbage collection.",
                        "B) The object will stay in memory until manually cleared by the programmer. ",
                        "C) The object will self-destruct once it reaches the end of the method. ",
                        "D) Finalize() is never called, and the object will persist in memory until the program ends.",
                        "a"
                }
    };

    public Level7() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions; }

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Chamber.jpg"; 
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
            "📜 Welcome to the Chamber of Secrets! 📜\n\n" +
            "You are about to embark on a quest to test all your Java knowledge at once.\n" +
            "Answer the questions correctly to unlock the final scroll of wisdom.\n\n" +
            "Beware! Time is limited, and your choice is crucial.\n" +
            "May the threads of your code never deadlock!"
        );
        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
            "🎉 Congratulations! 🎉\n\n" +
            "You have answered correctly!\n" +
            "You've unlocked the last scroll of lost knowledge of Javaria!\n\n" +
            "We wish you good luck on your endeavours\n"+
            "May your code always compile on the first try!"
        );
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.BOLD, 18));
        scrollText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();
}
}