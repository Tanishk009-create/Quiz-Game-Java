package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level3 extends BaseLevel {
    private final String[][] questions = {
        {
                    "In the sacred scrolls of Java, packages were born to—",
                    "Divide and conquer the growing realms of code.",
                    "Lock secrets behind layers of folders.",
                    "Control access to public spells.",
                    "Be ignored by the compiler if unnamed.",
                    "a"
            },
            {
                    "The incantation package mystic.code; is etched atop a scroll. What arcane effect does it summon?",
                    "It binds the class to a dimension called mystic.code.",
                    "It imports a secret archive into the class.",
                    "It encrypts the file against unauthorized access.",
                    "It assigns an alias for easier casting.",
                    "a"
            },
            {
                    "You seek to summon a scroll from a foreign package, but the compiler roars in defiance. What forgotten ritual did you neglect?",
                    "Import the scroll with a proper summoning spell.",
                    "Extend the scroll’s origin class.",
                    "Cast a static import.",
                    "Add package to your class.",
                    "a"
            },
            {
                    "The guardian of packages grants public, private, protected, and default. Which veil hides knowledge only within its own fortress?",
                    "default — the silent guardian of package walls.",
                    "protected — cousin to subclasses only.",
                    "public — a fool’s open gate.",
                    "private — protector of inner sanctums.",
                    "a"
            },
            {
                    "To summon all treasures from the vault treasures.hidden, what invocation must you utter?",
                    "import treasures.hidden.;",
                    "include all treasures.hidden;",
                    "import treasures.hidden.all();",
                    "package treasures.hidden.;",
                    "a"
            },
            {
                    "If Scroll.java dwells in the ancient.knowledge directory but lacks a package seal, what chaos befalls your craft?",
                    "The compiler will allow it but ignore the folder.",
                    "A mismatch of realms will cause chaos.",
                    "JVM will treat it as a lost soul (default package).",
                    "The class will become abstract.",
                    "b"
            },
            {
                    "Two entities—Knight and Squire—reside in the same domain. Which cloak of access need not be worn for Knight to see Squire?",
                    "public",
                    "default (no modifier)",
                    "protected",
                    "private",
                    "b"
            },
            {
                    "When the enchantment import static spellbook.Magic.*; is cast, what change ripples through your spells?",
                    "You may summon static methods without naming their tome.",
                    "Only final magic can be called.",
                    "Variables become dynamic.",
                    "All constructors are imported.",
                    "a"
            },
            {
                    "If you forgo the import ritual but chant a fully qualified name, what fate awaits your spell?",
                    "The JVM accepts the full chant without error.",
                    "The compiler demands import as tribute.",
                    "Runtime fails due to missing metadata.",
                    "You must call super() in main.",
                    "a"
            },
            {
                    "The Oracle whispers, “Two scrolls with the same name may exist if…”",
                    "They reside in different dimensions (packages).",
                    "They use final.",
                    "One is abstract.",
                    "Both are static.",
                    "a"
            },
            {
                    "Why are the java.lang scrolls never explicitly summoned?",
                    "They lie in the heart of the JVM, ever-present.",
                    "They are deprecated.",
                    "They’re hidden unless a key is used.",
                    "They must be extended, not imported.",
                    "a"
            },
            {
                    "You enter a chamber filled with .java scrolls, yet none bear the mark of a package. Which realm claims them?",
                    "The chaotic dimension: default package.",
                    "The root of java.lang.",
                    "A ghost package with no name.",
                    "java.util, the fallback archive.",
                    "a"
            },
            {
                    "Which incantation unlocks the vault to a solitary scroll?",
                    "import potions.Healing;",
                    "import potions.*;",
                    "package potions;",
                    "open potions.Healing();",
                    "a"
            },
            {
                    "Why shun the default package when embarking on quests of grand scale?",
                    "It's forbidden in organized realms.",
                    "Importing from it across packages is impossible.",
                    "All its scrolls are public.",
                    "It’s deprecated and slow.",
                    "b"
            },
            {
                    "Your class bears the public sigil. The scroll's name must—",
                    "Match the class's honor and title.",
                    "Be anything — the compiler understands.",
                    "Reflect its parent package.",
                    "Be in all caps.",
                    "a"
            },
            {
                    "To unveil your own package to the realm, you must:",
                    "Organize files in folders and declare package lines.",
                    "Compile with the --manifest flag.",
                    "Register it in java.lang.",
                    "Use export package.name;",
                    "a"
            },
            {
                    "In the modular Java era (Jigsaw), how are packages guarded?",
                    "With module-info.java scrolls at the gates.",
                    "Through the import-module command.",
                    "By linking JAR files in the default package.",
                    "By nesting one package inside another.",
                    "a"
            },
            {
                    "You discover a method in a package-private class. Can you summon it from beyond its borders?",
                    "No — it guards itself unless made public.",
                    "Yes — but only through reflection magic.",
                    "Only if static.",
                    "Only if subclassed.",
                    "a"
            },
            {
                    "Two packages dwell within the same directory. What ancient order must you observe?",
                    "Maintain separate folder hierarchies to reflect package paths.",
                    "Use nested interfaces.",
                    "Invoke each with packageName.*.",
                    "Use classloaders to separate them.",
                    "a"
            },
            {
                    "You chant thus:\nimport java.util.Date;\nimport java.sql.Date;\nDate d = new Date();\nWhy does the compiler revolt?",
                    "The ambiguity between two Dates confuses the ancient runes.",
                    "You didn't specify which Date to summon.",
                    "Both packages override each other.",
                    "java.sql is deprecated.",
                    "b"
            }
    };

    public Level3() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions; }

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Corridor.jpg"; 
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
            "📜: The Corridors of Containment — Packages! 📜\n\n" +
            "Wander the endless corridors where order meets modularity.\n\n" +
            "Packages seal off chaos, guiding your imports and hiding secrets.\n" +
            "Navigate wisely — for structure is survival, and one wrong path can unleash naming wars."
        );
        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
                "🎉 Congratulations, Seeker of Knowledge! 🎉\n\n" +
                        "You have answered all questions correctly.\n" +
                        "You have uncovered the lost knowledge of Javaria!\n\n" +
                        "Packages shall now bow to your command.\n\n" +
                        "May the JVM guide your path!");
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.ITALIC, 16));
        scrollText.setMargin(new Insets(20, 20, 20, 20));
        scrollText.setBackground(new Color(255, 250, 230)); // parchment-like

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 250));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();
    }
}
