package game.levels;

import game.GameStage;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;

public abstract class BaseLevel extends JFrame implements GameStage {
    protected JLabel questionLabel, timerLabel;
    protected JButton[] optionButtons = new JButton[4];
    protected Timer timer;
    protected int timeLeft;
    protected int currentQuestionIndex = 0;
    protected int score = 0;
    protected List<Integer> selectedQuestions = new ArrayList<>();
    protected Runnable onCompleteListener;

    public BaseLevel(int timeLimit) {
        this.timeLeft = timeLimit;
        setupUI();
    }

    protected abstract String[][] getQuestions();
    protected abstract String getBackgroundImagePath();
    protected abstract void showIntroScroll();
    protected abstract void showCompletionMessage();

    protected void setupUI() {
        setTitle("Java Quest");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon(getBackgroundImagePath());
                g.drawImage(icon.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(new BorderLayout());

        // Timer label
        timerLabel = new JLabel("Time Left: " + timeLeft + " seconds", SwingConstants.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel.setForeground(Color.YELLOW);

        JPanel timerPanel = new JPanel(new BorderLayout());
        timerPanel.setOpaque(false);
        timerPanel.setBorder(BorderFactory.createEmptyBorder(50, 0, 0, 0));
        timerPanel.add(timerLabel, BorderLayout.CENTER);
        panel.add(timerPanel, BorderLayout.NORTH);

        // Question panel
        JPanel centerPanel = new JPanel();
        centerPanel.setOpaque(false);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 40, 40, 40));

        questionLabel = new JLabel("", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Serif", Font.PLAIN, 26));
        questionLabel.setForeground(Color.WHITE);
        questionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        questionLabel.setMaximumSize(new Dimension(800, 300));
        questionLabel.setOpaque(false); 
        centerPanel.add(questionLabel);

        JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        optionsPanel.setOpaque(false);
        optionsPanel.setMaximumSize(new Dimension(600, 200));
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JButton();
            final int index = i;
            optionButtons[i].addActionListener(e -> checkAnswer(index));
            optionsPanel.add(optionButtons[i]);
        }
        centerPanel.add(optionsPanel);
        panel.add(centerPanel, BorderLayout.CENTER);

        setContentPane(panel);
    }

    protected void startTimer() {
        timer = new Timer(1000, e -> {
            timeLeft--;
            timerLabel.setText("Time Left: " + timeLeft + " seconds");
            if (timeLeft <= 0) endGame("Time's up!");
        });
        timer.start();
    }

    protected void loadNextQuestion() {
        if (currentQuestionIndex >= selectedQuestions.size()) {
            endGame("Quiz Over! Score: " + score + "/3");
            return;
        }
        
        String[] q = getQuestions()[selectedQuestions.get(currentQuestionIndex)];
        questionLabel.setText("<html><div style='width:700px;'>" + q[0] + "</div></html>");
        
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText("<html><div style='width:280px;'>" + q[i+1] + "</div></html>");
        }
    }

    protected void checkAnswer(int selected) {
        String[] q = getQuestions()[selectedQuestions.get(currentQuestionIndex)];
        String correct = q[5].toLowerCase();
        String[] options = {"a", "b", "c", "d"};
        
        if (options[selected].equals(correct)) {
            score++;
            currentQuestionIndex++;
            loadNextQuestion();
        } else {
            endGame("Wrong! Correct answer: " + correct.toUpperCase());
        }
    }

    protected void endGame(String message) {
    timer.stop();
    if (score >= 3) {
        showCompletionMessage();
        
        // Clear existing listeners
        for (KeyListener listener : getKeyListeners()) {
            removeKeyListener(listener);
        }
        
        // Add fresh listener
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    dispose();
                    if (onCompleteListener != null) {
                        SwingUtilities.invokeLater(onCompleteListener);
                    }
                }
            }
        });
        
        // Force focus
        requestFocusInWindow();
    } else {
        JOptionPane.showMessageDialog(this, message);
        System.exit(0);
    }
}

    @Override
    public void start() {
        selectRandomQuestions();
        showIntroScroll();
        setVisible(true);
        startTimer();
        loadNextQuestion();
    }

    @Override
    public void setOnCompleteListener(Runnable listener) {
        this.onCompleteListener = listener;
    }

    private void selectRandomQuestions() {
        Random rand = new Random();
        while (selectedQuestions.size() < 3) {
            int index = rand.nextInt(getQuestions().length);
            if (!selectedQuestions.contains(index)) {
                selectedQuestions.add(index);
            }
        }
    }
}