package game.levels;

import java.awt.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Level5 extends BaseLevel {
    private final String[][] questions = {
        {
                    "You find a contract with no body, yet it binds all who sign it. What is this artifact?",
                    "An interface — all promise, no flesh",
                    "An abstract class",
                    "A functional method",
                    "A lambda-bound parchment",
                    "a"
            },
            {
                    "The mirror shows you a method inside an interface... and it has a body! How is this betrayal allowed?",
                    "It's a default method — mirrors need fallback reflections",
                    "All interfaces allow full method bodies now",
                    "It's private — hidden beneath the glass",
                    "It's a constructor in disguise",
                    "a"
            },
            {
                    "The council forbids what inside an interface?",
                    "Constructors — interfaces birth no objects",
                    "Constants — too rigid for reflection",
                    "Static methods",
                    "Nested types",
                    "a"
            },
            {
                    "Which of these spells is always public in an interface, even when hidden?",
                    "Method declarations",
                    "Static blocks",
                    "Constructors",
                    "Instance variables",
                    "a"
            },
            {
                    "You write:\njava\nCopyEdit\ninterface Mirror {\n    void reflect() {}\n}\nThe compiler screams. Why?",
                    "You gave a method body with no default or static cloak",
                    "Interfaces can’t reflect",
                    "Syntax mirror cracked",
                    "You forgot to implement reflect()",
                    "a"
            },
            {
                    "The interface holds a constant like this:\njava\nCopyEdit\nint VALUE = 42;\nBut no access modifier is present. What enchantment is cast automatically?",
                    "public static final",
                    "private",
                    "protected static",
                    "static only",
                    "a"
            },
            {
                    "You enter a cave with two interfaces, both offering a default method called speak(). You implement both. Now what?",
                    "Ambiguity riddle! You must override speak() yourself",
                    "Java picks the last loaded",
                    "JVM merges both implementations",
                    "Runtime error, not compile",
                    "a"
            },
            {
                    "What happens when a class implements an interface but doesn’t define all its abstract methods?",
                    "The class must be abstract — it’s incomplete",
                    "Compiler fills in defaults",
                    "The program crashes at runtime",
                    "The interface is discarded",
                    "a"
            },
            {
                    "The scroll reads:\njava\nCopyEdit\ninterface A {\n    static void hello() {\n        System.out.println(\"Hello\");\n    }\n}\nYou try calling hello() from an implementing class instance. What happens?",
                    "It fails — static methods stay with their originators",
                    "It prints “Hello”",
                    "Throws NoSuchMethodError",
                    "You must override it",
                    "a"
            },
            {
                    "Two paths lie ahead: abstract class or interface. One can have instance variables. Which?",
                    "Abstract class — it holds memory",
                    "Interface — all is shared",
                    "Interface, but only static",
                    "Neither — both are empty shells",
                    "a"
            },
            {
                    "You cast a lambda spell like this:\njava\nCopyEdit\n() -> System.out.println(\"Cast!\")\nIt only works with certain interfaces. Why?",
                    "Only functional interfaces accept lambda rites",
                    "Only interfaces with one variable",
                    "Only static methods work",
                    "Only inner interfaces allow lambdas",
                    "a"
            },
            {
                    "You try to extend multiple classes. Java says no. But with interfaces?",
                    "Yes — you may inherit many scrolls",
                    "No — interfaces behave like classes",
                    "Only if they’re private",
                    "Only in sealed classes",
                    "a"
            },
            {
                    "An interface extends another interface. What must it do?",
                    "Nothing — it inherits methods silently",
                    "Override all methods",
                    "Be marked abstract",
                    "Be final",
                    "a"
            },
            {
                    "Which interface addition broke tradition in Java 8?",
                    "default methods — mirrors started talking",
                    "Final variables",
                    "Instance constructors",
                    "Inner interfaces",
                    "a"
            },
            {
                    "You find a declaration:\njava\nCopyEdit\ninterface Shadow extends Light, Darkness { }\nIs this legal in the realm of Java?",
                    "Yes — interfaces can extend multiple",
                    "No — only one parent allowed",
                    "Only with annotations",
                    "Only from abstract classes",
                    "a"
            },
            {
                    "An interface has a method marked default. Can it be final too?",
                    "No — mirrors must allow overriding",
                    "Yes — to seal the reflection",
                    "Only in nested interfaces",
                    "Only if static",
                    "a"
            },
            {
                    "What do these three always have in common in an interface?\n• Constants\n• Method names\n• Static methods",
                    "All are implicitly public",
                    "All must be abstract",
                    "All need semicolons",
                    "All are private",
                    "a"
            },
            {
                    "The compiler speaks:\n\"Error: Modifier private not allowed here.\"\nYou tried to mark a method in an interface. Which one caused the rage?",
                    "A method marked private before Java 9",
                    "A method marked protected",
                    "A method with no modifier",
                    "A method with default body",
                    "b"
            },
            {
                    "Which method type is allowed inside an interface starting Java 9?",
                    "private methods — hidden helpers in the mirror",
                    "protected methods",
                    "Constructors",
                    "Static blocks",
                    "a"
            },
            {
                    "You have:\njava\nCopyEdit\ninterface Wand {\n    default String spell() { return \"Zap\"; }\n}\nclass Staff implements Wand { }\nWhat happens if you call new Staff().spell()?",
                    "It prints “Zap” — default method inherited",
                    "Compile error",
                    "Requires override",
                    "JVM throws NoSuchMethodError",
                    "a"
            }
    };

    public Level5() {
        super(60);
    }

    @Override
    protected String[][] getQuestions() { return questions; }

    @Override
    protected String getBackgroundImagePath() { 
        return "C:/Users/TANISHK TIWARI/Desktop/Tanishk/SEM 2/Object Oriented Programming/Practicals/game/photos/Mirror Hall.jpg"; 
    }

    @Override
    protected void showIntroScroll() {
        JTextArea introText = new JTextArea(
            "📜: The Hall of Mirrors — Interface  Riddles! 📜\n\n" +
            "In this hall, nothing is what it seems.\n\n" +
            "Words echo, contracts bind without bodies, and reflections tease the eyes. \n" +
            "Only those who understand the rules of Java interfaces may pass..."
        );
        introText.setWrapStyleWord(true);
        introText.setLineWrap(true);
        introText.setEditable(false);
        introText.setFont(new Font("Serif", Font.BOLD, 18));
        introText.setBackground(new Color(240, 240, 200));

        JScrollPane scrollPane = new JScrollPane(introText);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(null, scrollPane, "The Chamber Awaits...", JOptionPane.PLAIN_MESSAGE);
    }

    @Override
    protected void showCompletionMessage() {
        JTextArea scrollText = new JTextArea(
                "🎉 Congratulations, Seeker of Knowledge! 🎉\n\n" +
                        "You have answered all questions correctly.\n" +
                        "You have uncovered the lost knowledge of Javaria!\n\n" +
                        "Interfaces shall now bow to your command.\n\n" +
                        "May the JVM guide your path!");
        scrollText.setWrapStyleWord(true);
        scrollText.setLineWrap(true);
        scrollText.setEditable(false);
        scrollText.setFont(new Font("Serif", Font.ITALIC, 16));
        scrollText.setMargin(new Insets(20, 20, 20, 20));
        scrollText.setBackground(new Color(255, 250, 230)); // parchment-like

        JScrollPane scrollPane = new JScrollPane(scrollText);
        scrollPane.setPreferredSize(new Dimension(400, 250));

        JLabel completionLabel = new JLabel("Press ENTER to continue...");
    completionLabel.setFont(new Font("Serif", Font.BOLD, 32));
    completionLabel.setForeground(Color.YELLOW);
    completionLabel.setHorizontalAlignment(SwingConstants.CENTER);
    
    add(completionLabel, BorderLayout.SOUTH);
    revalidate();
    repaint();
    }
}