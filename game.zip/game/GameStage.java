package game;

public interface GameStage {
    void start();
    void setOnCompleteListener(Runnable listener);
}