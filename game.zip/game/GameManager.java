package game;

import game.levels.*;
import game.story.*;
import javax.swing.SwingUtilities;

public class GameManager {
    private final GameStage[] stages;
    private int currentStageIndex = -1;

    public GameManager() {
        stages = new GameStage[] {
            new PrologueDisplay(),
            new Level1(),
            new Level2(),
            new Level3(),
            new Level4(),
            new Level5(),
            new Level6(),
            new Level7(),
            new EpilogueDisplay()
        };
    }

    public void startGame() {
        SwingUtilities.invokeLater(() -> startNextStage());
    }

    private void startNextStage() {
        currentStageIndex++;
        if (currentStageIndex >= stages.length) return;
        
        GameStage currentStage = stages[currentStageIndex];
        currentStage.setOnCompleteListener(() -> {
            SwingUtilities.invokeLater(this::startNextStage);
        });
        currentStage.start();
    }

    public static void main(String[] args) {
        new GameManager().startGame();
    }
}